int lock_device (int dev_ind);
int unlock_device (int dev_ind);
int create_semaphore (int dev_ind);
void semaphore_initialize( void );
