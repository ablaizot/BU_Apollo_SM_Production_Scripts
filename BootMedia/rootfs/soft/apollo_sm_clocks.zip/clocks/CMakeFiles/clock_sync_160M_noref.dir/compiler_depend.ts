# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for clock_sync_160M_noref.
